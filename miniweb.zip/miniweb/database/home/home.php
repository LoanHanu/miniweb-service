<?php
extract($_POST);
require_once '../../database/common/db_connect.php';

$query = "INSERT INTO data 
        (id, text, data, reply)
        VALUES (".($id * 1).", '". $text."',".($data * 1).", ". ($data * 1 + 1).")";
$qresult = mysqli_query($db,$query);
if($qresult){
    $last_id = $db->insert_id;
    require_once '../../database/common/db_disconnect.php';

    $title = 'MWS | Home';
    $description = "Mini Web Service";
    $author = "585";
    header('Location:'.'../../view/home/home.php?title='.$title.'&desription='.$description.'&author='.'&last_id='.$last_id);
}else{
    echo "There is a problem in server";
}

?>

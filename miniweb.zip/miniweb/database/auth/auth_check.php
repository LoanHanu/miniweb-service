<?php
require_once '../../includes/Bcrypt.php';
require_once '../../database/common/db_connect.php';
session_start();
$cls = new Bcrypt();

$email = trim($_POST['email']);
$password = trim($_POST['password']);
$query = "select * from users where email = '".$email."'";
$qresult = mysqli_query($db,$query);
$row = mysqli_fetch_array($qresult,MYSQLI_ASSOC);
$is_auth = $cls->check_password($password,$row['password']);
$_SESSION['username'] = $row['username'];
$_SESSION['auth_check'] = $is_auth;
require_once '../../database/common/db_disconnect.php';

$title = 'MWS | Home';
$description = "Mini Web Service";
$author = "585";
header('Location:'.'../../view/home/home.php?title='.$title.'&desription='.$description.'&author='.$author);
?>

<?php
mysqli_close($db);
?>
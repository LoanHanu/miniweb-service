<?php
$app_name = "miniweb";

$active_group = 'default';
$query_builder = TRUE;
$hostname = '%HOSTNAME%';
$username = '%USERNAME%';
$password = '%PASSWORD%';
$database = '%DATABASE%';
?>

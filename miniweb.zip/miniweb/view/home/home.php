<?php
include_once('../common/page_header.php');
require_once('../../common/auth_check.php');
if(isset($last_id)){
    $query = "select * from data where pid = ".$last_id;
    $qresult = mysqli_query($db,$query);
    $row = mysqli_fetch_array($qresult,MYSQLI_ASSOC);
}
?>

    <div class="auth-page-wrapper pt-5" style="background: gainsboro;">
        <!-- auth page bg -->

        <!-- auth page content -->
        <div class="auth-page-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center mt-sm-5 mb-4 text-white-50">
                            <div>
                                <a href="#" class="d-inline-block auth-logo">
                                    <h1> Mini Web Service</h1>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end row -->

                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card mt-4">

                            <div class="card-body p-4">
                                <div class="text-center mt-2">
                                    <h5 class="text-primary">Please Input Your Values</h5>
                                </div>
                                <div class="p-2 mt-4">
                                    <form class="x" action="../../database/home/home.php" method="post">

                                        <div class="mb-3">
                                            <label for="id" class="form-label">Id<span class="text-danger">*</span></label>
                                            <input type="number" class="form-control" name="id" id="id" placeholder="Enter Your Id" required/>
                                            <div class="invalid-feedback">
                                                Please enter id
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="text">Text</label>
                                            <div class="position-relative auth-pass-inputgroup">
                                                <input type="text" class="form-control pe-5" name="text" placeholder="Enter Text" id="text" required/>
                                                <div class="invalid-feedback">
                                                    Please enter text
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="data">Data</label>
                                            <div class="position-relative auth-pass-inputgroup">
                                                <input type="number" class="form-control pe-5" name="data" placeholder="Enter Data" id="data" required/>
                                                <div class="invalid-feedback">
                                                    Please enter data
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mt-4">
                                            <input class="btn btn-success w-100" type="submit" value="Submit">
                                        </div>
                                    </form>

                                </div>
                            </div>
                            <!-- end card body -->
                        </div>
                        <!-- end card -->
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end auth page content -->

        <div class="container-fluid">
        <?php if(isset($row)) :?>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Request</h5>
                            <div class="table-responsive">
                                <table class="table table-borderless mb-0">
                                    <thead>
                                    <th>ID</th>
                                    <th>Text</th>
                                    <th>Data</th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><?php echo $row['id']?></td>
                                        <td><?php echo $row['text']?></td>
                                        <td><?php echo $row['data']?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- end card body -->
                    </div>

                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Reply</h5>
                            <div class="table-responsive">
                                <table class="table table-borderless mb-0">
                                    <thead>
                                    <th>ID</th>
                                    <th>Reply</th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><?php echo $row['id']?></td>
                                        <td><?php echo $row['reply']?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- end card body -->
                    </div>
                </div>

            </div>
        <?php endif?>
        </div>
    </div>
<?php include_once('../common/page_footer.php');
?>
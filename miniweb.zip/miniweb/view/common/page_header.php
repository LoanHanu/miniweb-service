<?php
require_once ('../../common/constant.php');
include_once('../../database/common/db_connect.php');
extract($_GET);

?>
<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
      data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <title><?php echo $title?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo $description?>" name="description" />
    <meta content="<?php echo $author?>" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo BASE_URL?>/assets/images/favicon.ico">

    <!-- CSS -->
    <link href="<?php echo BASE_URL?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL?>/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo BASE_URL?>/assets/css/custom.min.css" rel="stylesheet" type="text/css" />

    <!-- Scripts -->
    <script src="<?php echo BASE_URL?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo BASE_URL?>/assets/js/layout.js"></script>

</head>

<body>

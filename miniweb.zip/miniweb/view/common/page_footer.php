<?php
include_once('../../database/common/db_disconnect.php');
?>

<!-- JAVASCRIPT -->
<script src="<?php echo BASE_URL?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASE_URL?>/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo BASE_URL?>/assets/libs/node-waves/waves.min.js"></script>
<script src="<?php echo BASE_URL?>/assets/libs/feather-icons/feather.min.js"></script>
<script src="<?php echo BASE_URL?>/assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
<!--<script src="--><?php //echo BASE_URL?><!--/assets/js/plugins.js"></script>-->
<!--<script type='text/javascript' src='--><?php //echo BASE_URL?><!--/assets/libs/choices.js/public/assets/scripts/choices.min.js'></script>-->
<!--<script type='text/javascript' src='--><?php //echo BASE_URL?><!--/assets/libs/flatpickr/flatpickr.min.js'></script>-->
<!-- prismjs plugin -->
<script src="<?php echo BASE_URL?>/assets/libs/prismjs/prism.js"></script>

<!-- App js -->
<!--<script src="--><?php //echo BASE_URL?><!--/assets/js/app.js"></script>-->

</body>


<!-- Mirrored from themesbrand.com/velzon/html/material/tables-basic.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Jun 2022 06:28:36 GMT -->
</html>
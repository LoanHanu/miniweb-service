<?php
session_start();
if(!isset($_SESSION['auth_check']) || $_SESSION['auth_check'] == false){
    $title = 'MWS | Login';
    $description = "This is login page";
    $author = "585";
    header('location:../../view/auth/login.php?title='.$title.'&description='.$description.'&author='.$author);
    die();
}
?>
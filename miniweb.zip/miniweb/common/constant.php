<?php
include_once ('../../database.php');
define('BASE_URL','http://'.$_SERVER['HTTP_HOST'].'/'.$app_name);
?>

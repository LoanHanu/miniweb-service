<?php
if(is_file('database.php')){
    $title = 'MWS | Home';
    $description = "Mini Web Service";
    $author = "585";
    header('Location:'.'view/home/home.php?title='.$title.'&desription='.$description.'&author='.$author);
}
else{
    header('Location:'.'install/');
}
?>